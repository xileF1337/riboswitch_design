package Math::Optimize::Walker::Decide;

use v5.12;
use warnings;
use autodie ':all';

use Carp qw( carp croak );
use IO::Null;

# Generates a Metropolis--Hastings style decision function with a given
# scale factor. This function can be passed an old state's score and a new
# state's score, and it will either accept (returns 1) or reject (returns
# false) the transition to this new state. If the new state has a lower
# score, the transition is always accepted. Otherwise, it is accepted with
# a probability that is proportional to the fraction of the probability of
# the old and new states (as calculated from their Boltzmann weight).
# Optional arguments:
#   scale_factor: Value from interval (0,inf). Lower values punish
#       tranisitons to worse states more severely; at high scale factors,
#       transitions are always accepted [1]
sub metropolis_hastings_factory {
    my ($scale_factor, $rand_gen) = @_;
    $scale_factor //= 1;
    $rand_gen     //= Math::Random::MT::Auto->new();

    return sub {
        my ($old_score, $new_score) = @_;

        # Always accept better states
        return 1 if $new_score <= $old_score;

        # TODO this always accepts equally good states. We don't want
        # that, do we?!

        # If new state is worse, accept with a probability proportional to
        # Boltzmann weight of the score / energy difference
        my $accept_prob = exp(  ($old_score-$new_score) / $scale_factor  );
        return $accept_prob > $rand_gen->rand(1);
    }
}

# Generate a decision function based on Simulated Annealing.
# Arguments:
#   temperature:     Initial temperature value. [1e4]
#   cooldown_factor: Factor from (0,1) which is multiplied with the
#                    current temperature in every call to mediate the
#                    annealing. [0.99]
#   epsilon:         Small positive number that is substracted from the
#                    energy difference of the old and new state. This is
#                    done to reduce the probability of transition if old
#                    and new state have equal energy. [1e-8]
sub simulated_annealing_factory {
    my ($temperature, $cooldown_factor, $epsilon, $opt) = @_;

    $temperature     //= 1000;
    $cooldown_factor //= 0.99;
    $epsilon         //= 1e-8;
    my $log      = $opt->{log} // IO::Null->new();  # by default, don't log
    my $rand_gen = Math::Random::MT::Auto->new(seed => $opt->{seed});

    croak 'Cooldown factor has to be from interval (0,1)'
        unless $cooldown_factor > 0 and $cooldown_factor < 1;

    croak 'Temperature must be positive' unless $temperature > 0;

    return sub {
        my ($old_score, $new_score) = @_;

        # Always accept better states
        return 1 if $new_score < $old_score;

        # If new state is worse, accept with a probability proportional to
        # Boltzmann weight of the score / energy difference.
        # If both old and new score are inf, let epsilon decide.
        my $score_diff = $old_score eq 'Inf' && $old_score eq 'Inf'
                         ? 0
                         : $old_score - $new_score;
        my $accept_probability = exp( ($score_diff-$epsilon) / $temperature );
        $log->printf( "  temp: %.4e  accept_prob: %5.2f",
                      $temperature, $accept_probability   );

        $temperature *= $cooldown_factor;           # cool down

        return $accept_probability > $rand_gen->rand(1);
    }
}

1;  # package Math::Optimize::Walker::Decide
