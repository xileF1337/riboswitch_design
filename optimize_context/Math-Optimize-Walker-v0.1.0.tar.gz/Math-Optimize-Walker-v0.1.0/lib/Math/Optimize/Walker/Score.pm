package Math::Optimize::Walker::Score;
# ONLY MENT FOR TESTING

use v5.12;
use warnings;
use autodie ':all';

# ONLY FOR TESTING
# Score GC content of sequence by returning negative count of Gs and Cs.
sub gc_content_score_factory {
    return sub {
        my $seq = shift;
        return -1 * grep {$_ eq 'G' or $_ eq 'C'} split //, $seq;
    };
}


# ONLY FOR TESTING
# Score GC content like above, however, add 1 to score (i.e. make it
# worse) if the sequence is completely made of GCs to have multiple global
# minima.
sub gc_multimin_score_factory {
    return sub {
        my $seq = shift;
        return -1*length($seq) + 1 if $seq =~ /^[GC]+$/;
        return -1 * grep {$_ eq 'G' or $_ eq 'C'} split //, $seq;
    };
}

1; # end of Math::Optimize::Walker::Score
