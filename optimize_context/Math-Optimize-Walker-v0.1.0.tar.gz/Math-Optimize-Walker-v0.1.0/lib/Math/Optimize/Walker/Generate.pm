package Math::Optimize::Walker::Generate;

use v5.12;
use warnings;
use autodie ':all';

use Carp qw( croak );
use Math::Random::MT::Auto;

# Generate a random seq of AUGCs (i.e., RNA) of a given length.
# Arguments:
#   length: length of sequence to be generated
#   rand_gen: a random number generator supporting the rand method
#       (e.g. from Math::Random::MT::Auto)
# Returns a random sequence of A, U, G and C of the requested length.
sub random_sequence {
    my ($length, $rand_gen) = @_;
    $rand_gen //= Math::Random::MT::Auto->new();# TODO may have high overhead

    state $symbols      = [qw( A U G C )];
    state $symbol_count = @$symbols;

    return join q{}, @{$symbols}[  map {int $rand_gen->rand($symbol_count)}
                                       1..$length
                                ];
}

# Build a sequence generator that, given either an initial sequence of a
# positive sequence lengths, randomly mutates one position of the sequence
# and returns the next sequence with each successive call. The returned
# generator is also capable of reverting the last mutation step when
# called with argument -1. If a length is passed to the factory, the
# initial sequence is a random sequence of that length.
# Required arguments: either but NOT both of...
#   sequence: use this as initial sequence and to determine target
#       sequence length
#   length: generate sequences of this length. Start with a random
#       sequence.
# Optional arguments: hash ref with following keys ...
#   seed: use this integer to seed the pseudo random number gen.
# Returns iterator that returns the next random sequence when called
# without arguments, and which reverts the last mutation step if called
# with argument -1. In this case, 1 is returned if reverting was
# successful, and a false value otherwise (i.e. no mutation done yet, or
# already reverted one step).
sub sequence_generator_factory {
    my ($arg, $opt) = @_;
    my ($seq_length, $current_seq);

    $arg = uc($arg =~ s/T/U/igr);    # ensure upper-case and substitute Ts

    # Generate pseudo-random number gen
    $opt //= {};
    my $rand_gen = Math::Random::MT::Auto->new(seed => $opt->{seed});

    # Check argument sanity.
    if ($arg =~/^\d+$/) {
        $seq_length = $arg;
        $current_seq = random_sequence $seq_length, $rand_gen;
    }
    elsif ($arg =~ /^[AUGC]+$/) {
        $current_seq = $arg;
        $seq_length = length $arg;
    }
    else {
        croak "Invalid argument '$arg'";
    }

    # State variables.
    my ($last_pos, $last_symbol);    # for reverting the last change

    return sub {
        if (@_ and $_[0] == -1) {               # revert last change
            # Nothing generated yet or already reverted one step
            return unless defined $last_symbol;

            substr $current_seq, $last_pos, 1, $last_symbol;    # undo
            $last_symbol = undef;
            return 1;
        }

        # Gen next random position.
        my $next_pos = int $rand_gen->rand($seq_length);

        # Assign a new DISTINCT random sequence of length 1 to a random
        # position, i.e.  change exactly one nucleotide, and keep the
        # replaced one for revert to the last state later if requested.
        my $next_symbol;
        do {
            $next_symbol = random_sequence 1, $rand_gen;
            $last_symbol = substr $current_seq, $next_pos, 1, $next_symbol;
        } while $next_symbol eq $last_symbol;

        $last_pos = $next_pos;

        return $current_seq;
    }
}

1; # End of Math:Optimize::Walker::Generate
