package Math::Optimize::Walker::Misc;

use v5.12;
use warnings;
use autodie ':all';

use Carp qw( croak );

# Builds a function that checks the validity of an argument list
# consisting of hash keys. It checks both that required arguments are
# present and that all present arguments are valid (i.e. either required
# or optional)
# Arguments:
#   required_args: List (ref) of required arguments.
#   valid_args: other valid (i.e. optional) arguments. All required
#       arguments are also considered valid.
# Returns void function that dies with an informative error message if
# invalid arguments are present or required arguments are missing.
sub arg_checker_factory ($++) {
    my ($class, $required_args, $valid_args) = @_;

    my %valid_args = map { $_ => 1 } @$valid_args, @$required_args;

    return sub {
        # Set valid args here
        state $required_args = [ qw(
        )];

        my @invalid_args = grep {not $valid_args{$_}} @_;
        croak "Class $class: Invalid arg(s) " . join(', ', @invalid_args)
            if @invalid_args;

        my  %passed_args = map  { $_ => 1            } @_;
        my @missing_args = grep {not $passed_args{$_}} @$required_args;
        croak "Class $class: Missing required arg(s) "
                . join( ', ', @missing_args)
            if @missing_args;
    }
}

1; # End of Optimize::Walk::Misc
