package Math::Optimize::Walker;

our $VERSION = 'v0.1';

use v5.12;
use warnings;

use List::Util qw( all );
use IO::Null;

use Math::Optimize::Walker::Misc;

sub new {
    my $class = shift;
    my $self  = bless {@_}, $class;

    # Check for required args
    my $check_args = do {
        my @required_args = qw(
                    score_func
                    generator
        );
        my @optional_args = qw(
                    default_max_successive_fails
                    decision_func
                    init_state
                    log
        );
        Math::Optimize::Walker::Misc::arg_checker_factory(
                                                   $class,
                                                   @required_args,
                                                   @optional_args
                                                 );
    };
    $check_args->(keys %$self);

    # Let run() stop after n unsuccessful iterations by default
    $self->{default_max_successive_fails} = 100
        unless defined $self->{default_max_successive_fails};

    # By default, perform simple gradient descent
    $self->{decision_func} ||= sub { my ($old, $new) = @_; $new < $old };

    # Generate initial state unless one has been specified
    $self->{init_state} = $self->{generator}()
        unless defined $self->{init_state};
    $self->{init_state_score} = $self->{score_func}($self->init_state);

    # TODO actually, for nested state structures, we need a deep copy
    $self->{current_state}       = $self->{init_state};
    $self->{current_state_score} = $self->{init_state_score};

    $self->{log} ||= IO::Null->new();           # by default, don't log

    return $self;
}


# Perform single MINIMIZATION step (well, depending on descision function)
sub step {
    my $self             = shift;
    my $next_state       = $self->{generator}();
    my $next_state_score = $self->{score_func}($next_state);
    $self->{log}->printf( "Step %5d:  next state: $next_state  score: %.4e",
                          $self->successful_step_count, $next_state_score);
    $self->{step_count}++;

    # On success, update current score
    if ($self->{decision_func}(
                                $self->current_state_score,
                                $next_state_score,
                              )
       ) {
        $self->{current_state}         = $next_state;
        $self->{current_state_score}   = $next_state_score;
        $self->{successful_step_count}++;
        $self->{log}->say('  => success');

        return 1;                           # sucess
    }
    else {
        $self->{generator}(-1);             # revert last step
        $self->{log}->say('  => fail');

        return;                             # fail
    }
}


# Continue performing optimization steps until the maximal number of
# successive rejections has been reached.
# Optional arguments:
#   max_successive_fails: Allow up to that many failed steps until giving
#       up.
sub run {
    my $self = shift;
    my $max_successive_fails = @_
                               ? shift
                               : $self->{default_max_successive_fails};

    my $successive_fail_count = 0;
    while ($successive_fail_count <= $max_successive_fails) {
        if ($self->step()) {
            $successive_fail_count = 0;
        }
        else {
            $successive_fail_count++;
        }
    }

    $self->{log}->say("Walk: finished.");
    return ($self->current_state, $self->current_state_score);
}


# Public getters
sub init_state            { $_[0]->{init_state}                 }
sub init_state_score      { $_[0]->{init_state_score}           }
sub current_state         { $_[0]->{current_state}              }
sub current_state_score   { $_[0]->{current_state_score}        }
sub step_count            { $_[0]->{step_count} || 0            }
sub successful_step_count { $_[0]->{successful_step_count} || 0 }


return 1 if caller;                 # usage as module
# End of Math::Optimize::Walker


##############################################################################
##                              Example Usage                               ##
##############################################################################

say "Using the random sequence generator";

my $sequence_length = 15;                   # change at will
my $sequence_count  = 10;

my $random_seq_gen
    = Math::Optimize::Walker::Generate::sequence_generator_factory($sequence_length);
my %known_seq = ();

foreach (1..$sequence_count) {
    printf "%2d: ", $_;

    my $seq = $random_seq_gen->();
    $known_seq{$seq}++;

    if ($known_seq{$seq} > 1) {
        say $known_seq{$seq} . ". encounter";
    }
    else {
        say $seq;
    }
}

say "\nDemonstrating gradient walk optimization class.";
say "Starting with a random sequence, optimize the GC content";

my $score_gc_content = Math::Optimize::Walker::Score::gc_content_score_factory();
my $start_sequence   = 'A' x 15;
$random_seq_gen
    = Optimize::Walk::Generate::sequence_generator_factory($start_sequence);
my $decide_metropolis_hastings
    = Optimize::Walk::Decide::metropolis_hastings_factory( 0.5 );

my $grad_walk = Optimize::Walk->new(
    generator                    => $random_seq_gen,
    score_func                   => $score_gc_content,
    init_state                   => $start_sequence,
    default_max_successive_fails => 10,
    decision_func                => $decide_metropolis_hastings,
);

test_walk($grad_walk);


say "\nNow again with simulated annealing.";

$random_seq_gen
    = Math::Optimize::Walker::Generate::sequence_generator_factory($start_sequence);
my $decide_simulated_annealing
    = Math::Optimize::Walker::Decide::simulated_annealing_factory( 1e4, 0.990, 1e-8 );
my $score_gc_content_multimin
    = Math::Optimize::Walker::Score::gc_multimin_score_factory();
$grad_walk = Math::Optimize::Walk->new(
    generator                    => $random_seq_gen,
    score_func                   => $score_gc_content_multimin,
    init_state                   => $start_sequence,
    default_max_successive_fails => 0,
    decision_func                => $decide_simulated_annealing,
);

test_walk($grad_walk);


##############################################################################

# Perform the passed, initialized walk and print some nice infos.
sub test_walk {
    my $grad_walk = shift;

    say 'Gradwalking now..., start sequence: ', $grad_walk->init_state,
    '  score: ', $grad_walk->init_state_score;
    foreach (1..8) {
        my $success = $grad_walk->step ? "success" : "no success";
        say 'Gradwalking single step, result:    ', $grad_walk->current_state,
        '  score: ', $grad_walk->current_state_score, "  $success";
    }
    say 'Continuing...';
    $grad_walk->run( );
    say 'Gradwalking finished, result:       ', $grad_walk->current_state,
    '  score: ', $grad_walk->current_state_score;
    say 'performed ', $grad_walk->step_count, ' steps in total, ',
    $grad_walk->successful_step_count, ' of which were successful';
}

exit 0;

##############################################################################
##                              Documentation                               ##
##############################################################################

=head1 NAME

Math::Optimize::Walker - Optimize e.g. RNA sequences using random walks and
simulated annealing

=head1 VERSION

Version v0.1

=cut


=head1 SYNOPSIS

Module implementing optimization by means of simulated annealing and random
walks. The score function is minimized.

Primary use case is RNA sequence. This module is thread-safe; use e.g.
C<Parallel::Loops> to run multiple walkers in parallel.

    use Math::Optimize::Walker;
    use Math::Optimize::Walker::Generate;
    use Math::Optimize::Walker::Decide;

    # Build new generator / new initial sequence in each optimization attempt
    my $sequence_generator
        = Math::Optimize::Walker::Generate::sequence_generator_factory(
            $sequence_length,
            {seed => $rand_seed},
          );

    # Build new decision function which accepts or rejects the last
    # optimization step based on its score computed with the objective
    # function. Here, a simulated annealing is used (acceptance probability
    # decreases over time.
    my $decision_function
        = Math::Optimize::Walker::Decide::simulated_annealing_factory(
            $init_temperature,
            0.95,       # annealing_factor,
            1e-8,       # epsilon
            { log => $log },
          );

    # Number of neighbors of the sequence: each position can be mutated to one
    # of three different nucleotides.
    my $neighbor_count = 3 * $sequence_length;

    # Optimize sequence under the given objective function.
    my $walker = Math::Optimize::Walker->new(
        score_func    => $objective_function,
        generator     => $sequence_generator,
        decision_func => $decision_function,
        default_max_successive_fails => $neighbor_count,        # see below!
        log           => $log,
    );

    # This default_max_successive_fails setting ensures that, on average, a
    # fraction of 63% of the neighborhood of each sequence is sampled
    # before giving up. To sample on average a fraction of x of the space, set
    #   default_max_fails = -ln(1-x) * neighbor_count.
    # The rhs is the expected number of samples required to see x of all seqs.

    $walker->run();                 # perform optimization

    return ( $walker->init_state,    $walker->init_state_score,
             $walker->current_state, $walker->current_state_score,
             $walker->step_count,
    );


=head1 SUBROUTINES/METHODS

=head2 new()

Constructor.

=cut

sub function1 {
}

=head2 function2

=cut

sub function2 {
}

=head1 AUTHOR

Felix Kuehnl, C<< <felix at bioinf.uni-leipzig.de> >>

=head1 BUGS

Please report any bugs or feature requests to C<bug-math-optimize-walker at
rt.cpan.org>, or through the web interface at
L<https://rt.cpan.org/NoAuth/ReportBug.html?Queue=Math-Optimize-Walker>.  I
will be notified, and then you'll automatically be notified of progress on
your bug as I make changes.


=head1 SUPPORT

You can find documentation for this module with the perldoc command.

    perldoc Math::Optimize::Walker


You can also look for information at:

=over 4

=item * RT: CPAN's request tracker (report bugs here)

L<https://rt.cpan.org/NoAuth/Bugs.html?Dist=Math-Optimize-Walker>

=item * AnnoCPAN: Annotated CPAN documentation

L<http://annocpan.org/dist/Math-Optimize-Walker>

=item * CPAN Ratings

L<https://cpanratings.perl.org/d/Math-Optimize-Walker>

=item * Search CPAN

L<https://metacpan.org/release/Math-Optimize-Walker>

=back


=head1 ACKNOWLEDGEMENTS


=head1 LICENSE AND COPYRIGHT

Copyright 2020 Felix Kuehnl.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see L<http://www.gnu.org/licenses/>.


=cut

